#include <containers/mat.h>
using namespace LMT;

int main(  ) {
        Mat<double> m(10,10);
        for(unsigned i=0;i<m.nb_rows();++i)
                for(unsigned j=0;j<m.nb_cols();++j)
                        m(i,j) = i + j;
        PRINTN( m + 10 );
        std::cout << dot( m.diag(), range(m.nb_rows()) ) << std::endl;
}


