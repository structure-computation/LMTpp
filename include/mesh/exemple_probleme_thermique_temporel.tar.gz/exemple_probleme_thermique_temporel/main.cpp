#include "build/problem_thermique_temporel/problem.h"
#include "mesh/make_rect.h"

using namespace LMT;

template< class T, class POS>
T bulle( POS p, POS p_maxi ) {
    return (T) p[ 0 ] * p[ 1 ] * ( p_maxi[ 0 ] - p[ 0 ] ) * ( p_maxi[ 1 ] - p[ 1 ] ); 
}

int main(int argc, const char* argv[ ] ) {
    typedef double T;
    static const unsigned dim = 2;
     
    typedef Problem_thermique_temporel< T, dim > PB;
    typedef PB::TM TM;
    typedef TM::Pvec Pvec;

    T step_time = 1e-3;
    Pvec pos_maxi( 4, 1 );
    unsigned nb_pas_temps = 2000;
    unsigned k_elem = 10;

  
    
    TM m;
    make_rect( m, Triangle(), 0, pos_maxi, k_elem * ( pos_maxi + 1 ) );
    
    PB pb( m, true );

    for(unsigned i = 0; i < m.node_list.size(); ++i ) {
        if ( ( m.node_list[ i ].pos[ 0 ] < 1e-6 )  or 
             ( m.node_list[ i ].pos[ 0 ] > pos_maxi[ 0 ] - 1e-6 ) or 
             ( m.node_list[ i ].pos[ 1 ] < 1e-6 ) or 
             ( m.node_list[ i ].pos[ 1 ] > pos_maxi[ 1 ] - 1e-6 ) ) {
            pb.formulation_difftherm_normalise->add_constraint( "node_list[" + to_string(i) + "].temperature", 1e5 );
        } else {
            m.node_list[ i ].temperature = bulle<T>( m.node_list[ i ].pos, pos_maxi );
        }
    }
    
    pb.formulation_difftherm_normalise->set_initial_time_step( step_time );
    pb.formulation_difftherm_normalise->assume_constant_matrix = true;
    pb.formulation_difftherm_normalise->non_linear_iterative_criterium = 0.01; 
    
    DisplayParaview dp;
    dp.add_mesh( m, "tmp/res", Vec<std::string>("all"), 0 );
    
    for( unsigned j = 0; j < nb_pas_temps; ++j ) {
        pb.formulation_difftherm_normalise->solve();
        dp.add_mesh( m, "tmp/res", Vec<std::string>("all"), j + 1 );
        for(unsigned i = 0; i < m.node_list.size(); ++i ) {
            T t = j * step_time;
            m.node_list[ i ].Q = 5e2 * ( 0.15 + sin( 30 * t * m.node_list[ i ].pos[0] / pos_maxi[0] ) ) * ( 0.15 + sin( 10* t * m.node_list[ i ].pos[1] / pos_maxi[1] ) ) * bulle<T>( m.node_list[ i ].pos, pos_maxi );
        }
    }

    dp.exec();
    
    return 0;
}
