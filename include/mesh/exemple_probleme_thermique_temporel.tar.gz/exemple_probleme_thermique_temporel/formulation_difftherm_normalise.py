# -*- coding: utf-8 -*-
temperature = Variable( unknown=True, nb_der=1, default_value='0.0', unit='K' )
Q = Variable( default_value='0.0', unit='K/s' )

left_time_integration  = 0
right_time_integration = 1


#
def formulation():
  t,te = temperature.expr, temperature.test

  return ( dot( grad(t), grad(te) ) + ( t.diff(time) - Q.expr ) * te ) * dV
  
  
  
# ).subs( time, time_steps[0] )
#  + ( pos.expr[2] ) * ( pos.expr[0] < 1e-6 ) * te * dS + 
# therm_penalty = Variable( interpolation='global', default_value='1e6', unit='1' )
# contact_temperature = ISVariable( default_value='600', unit='K' )
# #
# def IS_contact_formulation(): return therm_penalty.expr * temperature.test * ( temperature.expr - contact_temperature.expr )
# def elem_contact_formulation(ve): return number(0)



