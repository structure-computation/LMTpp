
#include "mesh/make_rect.h"
#include "mesh/meshcaracstd.h"
#include "mesh/mesh.h"
#include "mesh/quad.h"
#include "mesh/quad_8.h"
#include "mesh/triangle.h"
#include "mesh/triangle_6.h"
//#include "mesh/element_Bar_3.h"
#include "mesh/hexa.h"
#include "mesh/interpolation.h"
//#include "mesh/element_Bar_3.h"

//#include "mesh/read_msh_2.h"

#include "mesh/displayparaview.h"
// #include "correlation/mesh_carac_correlation.h"

/*! inclusion du code de notre MeshCarac  */
#include "MonMeshCarac.h"

using namespace LMT;
using namespace std;

void test_2D() {
    typedef Mesh< Mesh_carac_MonMeshCarac< double,2> > TM;
    typedef TM::Pvec Pvec;
    typedef TM::TNode::T T;
    
    TM m;
    make_rect( m, Quad(), Pvec( 0, 0, 0 ), Pvec( 1., 1., 1. ), Pvec( 2,2,2 ) );
   
    for( unsigned i = 0 ; i < m.node_list.size(); ++i )
        m.node_list[i].courbure = i; 
     
    PRINT( interpolation( m, courbure_DM(), Pvec( 0.01, 0.02 ) ) );
    PRINT( interpolation( m, courbure_DM(), Pvec( 0.99, 0.01 ) ) );
    PRINT( interpolation( m, courbure_DM(), Pvec( 0.01, 0.99 ) ) );
    PRINT( interpolation( m, courbure_DM(), Pvec( 0.991, 0.992 ) ) );
    
    display_mesh(m);
}

void test_3D() {
    typedef Mesh< Mesh_carac_MonMeshCarac< double,3> > TM;
    typedef TM::Pvec Pvec;
    typedef TM::TNode::T T;
    
    TM m;
    make_rect( m, Hexa(), Pvec( 0, 0, 0 ), Pvec( 1., 1., 1. ), Pvec( 2,2,2 ) );
   
    for( unsigned i = 0 ; i < m.node_list.size(); ++i )
        m.node_list[i].courbure = i; 
     
    PRINT( interpolation( m, courbure_DM(), Pvec( 0.01, 0.02, 0.01 ) ) );
    PRINT( interpolation( m, courbure_DM(), Pvec( 0.99, 0.01, 0.01 ) ) );
    PRINT( interpolation( m, courbure_DM(), Pvec( 0.01, 0.99, 0.0446 ) ) );
    PRINT( interpolation( m, courbure_DM(), Pvec( 0.01, 0.02, 0.99446 ) ) );
    PRINT( interpolation( m, courbure_DM(), Pvec( 0.991, 0.992, 0.0446 ) ) );
    PRINT( interpolation( m, courbure_DM(), Pvec( 0.991, 0.02, 0.99446 ) ) );
    PRINT( interpolation( m, courbure_DM(), Pvec( 0.01, 0.992, 0.99446 ) ) );
    PRINT( interpolation( m, courbure_DM(), Pvec( 0.991, 0.992, 0.99446 ) ) );
    
    display_mesh(m);
}

int main(int argc,char **argv) {

    test_2D();
    // test_3D();
    
    return 0; 
}





