# -*- coding: utf-8 -*-

dep  = Variable( default_value='0.0', nb_dim=[dim], unit='m' )
ener = Variable( interpolation='elementary', default_value='0.0', unit='W/m^2/K' )
# Par défaut interpolation a la valeur 'nodal'
epsilon = Variable( interpolation='gauss', nb_dim=[3,3], default_value='0.0', unit='W/m^2/K' )

numsst = Variable( interpolation='global', default_value='0.0', unit='' )
sigma = Variable( interpolation='elementary', nb_dim=[6], default_value='0.0', unit='W/m^2/K' )
sigma_von_mises = Variable( interpolation='elementary', default_value='0.0', unit='W/m^2/K' )

#attribut_mortel = Variable( T='Mat<double,Gen<>,SparseUMFPACK,void>', unit='Jojo' )
# T précise le type exact de l'atribut
courbure  = Variable( default_value='0.0', unit='m' )

#
def formulation():
    return 0
  
  