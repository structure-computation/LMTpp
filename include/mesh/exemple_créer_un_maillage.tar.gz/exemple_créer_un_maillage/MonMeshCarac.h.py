# -*- coding: utf-8 -*-
from LMT.formal_lf import *

write_pb(
    name = 'MonMeshCarac',
    formulations = ['MonMeshCarac'],
    elements = ['Triangle','Triangle_6','Quad','Tetra','Hexa','Wedge'],
)