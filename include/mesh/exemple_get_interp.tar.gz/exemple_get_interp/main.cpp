#include "mesh/quad.h"
#include "mesh/quad_8.h"
#include "mesh/quad_9.h"
#include "mesh/triangle.h"
#include "mesh/triangle_6.h"
#include "mesh/element_Bar_3.h"
#include "mesh/hexa.h"
#include "mesh/element_Bar_3.h"
#include "util/load_image.h"

using namespace LMT;
using namespace std;

/**
 * petit exemple d'utilisation des fonctions get_interp(...) et get_shape_functions(...)
**/
int main(int argc,char* argv[]) {

    typedef double TT;

    Vec<TT,2> var_inter(0.2,0.3);
    TT res;
    get_interp( Quad(), Nodal(), var_inter,static_dirac_vec<Quad::nb_nodes>( 1.0, 0 ), res );
    PRINT(res);//   res -> 0.56
    get_interp( Quad_8(), Nodal(), var_inter,static_dirac_vec<Quad_8::nb_nodes>( 1.0, 1 ), res );
    PRINT(res);//   res -> -0.168
    get_interp( Triangle(), Nodal(), var_inter,static_dirac_vec<Triangle::nb_nodes>( 1.0, 0 ), res );
    PRINT(res);//   res -> 0.5
    get_interp( Triangle_6(), Nodal(), var_inter,static_dirac_vec<Triangle_6::nb_nodes>( 1.0, 1 ), res );
    PRINT(res);//   res -> -0.12

    Vec<TT,1> var_inter1(0.2);
    get_interp( Bar_3(), Nodal(), var_inter1,static_dirac_vec<Bar_3::nb_nodes>( 1.0, 0 ), res );
    PRINT(res);//   res -> 0.48

    Vec<TT,3> var_inter3(0.2,0.1,0.1);
    get_interp( Hexa(), Nodal(), var_inter3,static_dirac_vec<Hexa::nb_nodes>( 1.0, 0 ), res );
    PRINT(res);//   res -> 0.648

    static const int sizeM = 512;
    Mat<TT,Gen<sizeM,sizeM> > M; // ou bien Mat<TT> M(sizeM,sizeM,0.0);
    TT invSizeM = 1.0 / sizeM;

    typedef Triangle TEL;

    for(int k=0;k<TEL::nb_nodes;++k) {
        for(int i=0;i<sizeM;++i)
            for(int j=0;j<sizeM;++j) {
                get_interp( TEL(), Nodal(), Vec<TT,2>(j*invSizeM,i*invSizeM),static_dirac_vec<TEL::nb_nodes>( 1.0, k ), res );
                M(i,j) = res;
            }
        TT mini = min(M);
        TT maxi = max(M);
        TT a = 255./(maxi-mini);
        TT b = -a*mini;
        M = a*M+b;
        stringstream ss;
        ss << TEL::name() << "__" << k << "_fct_forme" ;
        display_image(M,ss.str());
    }
    return 0;
}
