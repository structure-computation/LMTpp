#include "mesh/make_rect.h"
#include "mesh/meshcaracstd.h"
#include "meshcaracillustration.h"
#include "mesh/mesh.h"
#include "mesh/quad.h"
#include "mesh/quad_8.h"
#include "mesh/triangle.h"
#include "mesh/triangle_6.h"
#include "mesh/element_Bar_3.h"
#include "mesh/hexa.h"
#include "mesh/element_Bar_3.h"

using namespace LMT;
using namespace std;

/*
Extrapole en un point du maillage.
*/
template <class T>
struct Interpolation_perso {
    void init() { sum = 0; }
    Interpolation_perso() { init();}
    template<class TE,class Pvec> void operator()( const TE &e, const Pvec &P ) {
        Vec<Pvec,TE::nb_nodes> pos_nodes;
        for(unsigned i=0;i<TE::nb_nodes;++i)
            pos_nodes[i] = e.node( i )->pos;

        Vec<typename TE::T,TE::nb_nodes> valeurs_elem;
        for(unsigned i=0;i<TE::nb_nodes;++i)
            valeurs_elem[i] = e.node( i )->scalar;

        Vec<typename TE::T,TE::dim> var_inter;
        get_var_inter( typename TE::NE(), pos_nodes, P, var_inter ); // cette fonction retourne dans var_inter les coordonnées de P dans le repère de référence 
        if ( var_inter_is_inside( typename TE::NE(), var_inter, std::numeric_limits<typename TE::T>::epsilon() * 10 ) ) {
            typename TE::T res ;
            get_interp( typename TE::NE(), Nodal(), var_inter,valeurs_elem, res );
            sum += res;
        } else
            cout << "pouet!" << endl;
    }

    T sum;
};

int main(int argc,char* argv[]) {

    typedef Quad NE;
    //typedef Triangle NE;
    //typedef Quad_9 NE;
    //typedef Triangle_6 NE;
    //typedef Quad_42 NE;
    //typedef Quad_8 NE;
    //typedef Quad_6 NE;
    typedef Mesh<MeshCaracIllustration<2,double> > TM;
    typedef TM::Pvec Pvec;

    TM m;
    make_rect( m, NE(), Pvec( 0, 0 ), Pvec( 1., 1. ), Pvec( 2, 2 ) );
    PRINT(m.node_list.size());
    PRINT(m.elem_list.size());
    if (m.elem_list.size() == 0) {
        cerr << "Arrêt brutal car il n' y a aucun élément dans le maillage..." << endl;
        return 1;
    }

    for(int i=0;i<m.node_list.size();++i)
        m.node_list[i].scalar = i;

    Interpolation_perso<TM::TNode::T> interpolation_perso;
    PRINT(interpolation_perso.sum);

    apply(m.elem_list,interpolation_perso,Pvec(0.2,0.3) );

    PRINT(interpolation_perso.sum);

    return 0;
}

