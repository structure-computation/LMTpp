#ifndef MESHCARAC_ILLUSTRATION_H
#define MESHCARAC_ILLUSTRATION_H

#include "mesh/nodalelement.h"
#include "mesh/triangle.h"
#include "mesh/quad.h"
#include "mesh/quad_9.h"
#include "mesh/quad_8.h"
#include "mesh/quad_6.h"
#include "mesh/quad_42.h"
#include "mesh/triangle_6.h"
#include "mesh/bar.h"
#include "mesh/tetra.h"
#include "mesh/hexa.h"
namespace LMT {

//template<unsigned nb_dim,class T> class MeshCaracIllustration;

#ifndef IFNDEF_pos_DM
#define IFNDEF_pos_DM
    struct pos_DM {};
#endif // IFNDEF_pos_DM

#ifndef IFNDEF_scalar_DM
#define IFNDEF_scalar_DM
    struct scalar_DM {};
#endif // IFNDEF_scalar_DM

#ifndef IFNDEF_vector_DM
#define IFNDEF_vector_DM
    struct vector_example_DM {};
#endif // IFNDEF_vector_example_DM

#ifndef IFNDEF_num_structure_DM
#define IFNDEF_num_structure_DM
    struct num_structure_DM {};
#endif // IFNDEF_num_structure_DM

template<unsigned nb_dim,class T> class MeshCaracIllustration {

};

template<class T> class MeshCaracIllustration<2,T> { 
public:
    static const unsigned dim = 2;
    static const unsigned dim_vector_example = 4;
    typedef T Tpos;
    typedef Vec<T,dim> Pvec;
    typedef Vec<T,dim_vector_example> Tvector_example;
    struct NodalStaticData {
        NodalStaticData():scalar(0.0),vector_example(0.0) {}
        //typedef Vec<T,1> T0;
        typedef T T0;
        CARACDMEXTNAME(0,T0,scalar,"");
        typedef Vec<T,dim_vector_example> T1;
        CARACDMEXTNAME(1,T1,vector_example,"");
        CARACDMEXTNAME(2,Pvec,pos,"m");
        static const unsigned nb_params = 3;
        void dm_data_set_field( const std::string field_name, Tpos value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,1> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,2> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,3> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,4> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,5> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,6> &value ) { assert(0); /*TODO*/ }
        template<class __G__> __G__ dm_data_get_field( const std::string field_name, StructForType<__G__> ) const { assert( 0 /*TODO*/ ); return __G__( 0.0 );  }
    };
    struct GlobalStaticData {
        VOIDDMSET;
        void dm_data_set_field( const std::string field_name, Tpos value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,1> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,2> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,3> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,4> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,5> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,6> &value ) { assert(0); /*TODO*/ }
        template<class __G__> __G__ dm_data_get_field( const std::string field_name, StructForType<__G__> ) const { assert( 0 /*TODO*/ ); return __G__( 0.0 );  }
    };
    struct TCDM0 {
        TCDM0():num_structure(0) {}
        CARACDMEXTNAME(0,unsigned,num_structure,"");
        static const unsigned nb_params = 1;
        void dm_data_set_field( const std::string field_name, Tpos value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,1> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,2> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,3> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,4> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,5> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,6> &value ) { assert(0); /*TODO*/ }
        template<class __G__> __G__ dm_data_get_field( const std::string field_name, StructForType<__G__> ) const { assert( 0 /*TODO*/ ); return __G__( 0.0 );  }
    };
    template<unsigned nvi_to_subs,unsigned skin,unsigned num_sub_element,unsigned inner=0>
    struct ElementChoice {
        typedef void NE;
        typedef DefaultBehavior BE;
        typedef VoidDMSet TData;
    };
    template<unsigned skin,unsigned inner> struct ElementChoice<0,skin,0,inner> {
        typedef Quad NE;
        typedef DefaultBehavior BE;
        typedef TCDM0 TData;
    };
    template<unsigned skin,unsigned inner> struct ElementChoice<0,skin,1,inner> {
        typedef Triangle NE;
        typedef DefaultBehavior BE;
        typedef TCDM0 TData;
    };
    template<unsigned skin,unsigned inner> struct ElementChoice<0,skin,2,inner> {
        typedef Quad_9 NE;
        typedef DefaultBehavior BE;
        typedef TCDM0 TData;
    };
    template<unsigned skin,unsigned inner> struct ElementChoice<0,skin,3,inner> {
        typedef Triangle_6 NE;
        typedef DefaultBehavior BE;
        typedef TCDM0 TData;
    };
    template<unsigned skin,unsigned inner> struct ElementChoice<0,skin,4,inner> {
        typedef Quad_42 NE;
        typedef DefaultBehavior BE;
        typedef TCDM0 TData;
    };
    template<unsigned skin,unsigned inner> struct ElementChoice<0,skin,5,inner> {
        typedef Quad_8 NE;
        typedef DefaultBehavior BE;
        typedef TCDM0 TData;
    };
    template<unsigned skin,unsigned inner> struct ElementChoice<0,skin,6,inner> {
        typedef Quad_6 NE;
        typedef DefaultBehavior BE;
        typedef TCDM0 TData;
    };
    template<unsigned skin,unsigned inner> struct ElementChoice<1,skin,0,inner> {
        typedef Bar NE;
        typedef DefaultBehavior BE;
        typedef TCDM0 TData;
    };
    template<unsigned skin,unsigned inner> struct ElementChoice<1,skin,1,inner> {
        typedef Bar_3 NE;
        typedef DefaultBehavior BE;
        typedef TCDM0 TData;
    };
    template<unsigned skin,unsigned inner> struct ElementChoice<1,skin,2,inner> {
        typedef Bar_4 NE;
        typedef DefaultBehavior BE;
        typedef TCDM0 TData;
    };
    template<unsigned inner> struct ElementChoice<2,0,0,inner> {
        typedef NodalElement NE;
        typedef DefaultBehavior BE;
        typedef TCDM0 TData;
    };
};

template<class T> class MeshCaracIllustration<3,T> { 
public:
    static const unsigned dim = 3;
    static const unsigned dim_vector_example = 4;
    typedef T Tpos;
    typedef Vec<T,dim> Pvec;
    typedef Vec<T,dim_vector_example> Tvector_example;
    struct NodalStaticData {
        NodalStaticData():scalar(0.0),vector_example(0.0) {}
        //typedef Vec<T,1> T0;
        typedef T T0;
        CARACDMEXTNAME(0,T0,scalar,"");
        typedef Vec<T,dim_vector_example> T1;
        CARACDMEXTNAME(1,T1,vector_example,"");
        CARACDMEXTNAME(2,Pvec,pos,"m");
        static const unsigned nb_params = 3;
        void dm_data_set_field( const std::string field_name, Tpos value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,1> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,2> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,3> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,4> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,5> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,6> &value ) { assert(0); /*TODO*/ }
        template<class __G__> __G__ dm_data_get_field( const std::string field_name, StructForType<__G__> ) const { assert( 0 /*TODO*/ ); return __G__( 0.0 );  }
    };
    struct GlobalStaticData {
        VOIDDMSET;
        void dm_data_set_field( const std::string field_name, Tpos value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,1> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,2> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,3> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,4> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,5> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,6> &value ) { assert(0); /*TODO*/ }
        template<class __G__> __G__ dm_data_get_field( const std::string field_name, StructForType<__G__> ) const { assert( 0 /*TODO*/ ); return __G__( 0.0 );  }
    };
    struct TCDM0 {
        TCDM0():num_structure(0) {}
        CARACDMEXTNAME(0,unsigned,num_structure,"");
        static const unsigned nb_params = 1;
        void dm_data_set_field( const std::string field_name, Tpos value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,1> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,2> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,3> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,4> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,5> &value ) { assert(0); /*TODO*/ }
        void dm_data_set_field( const std::string field_name, const Vec<Tpos,6> &value ) { assert(0); /*TODO*/ }
        template<class __G__> __G__ dm_data_get_field( const std::string field_name, StructForType<__G__> ) const { assert( 0 /*TODO*/ ); return __G__( 0.0 );  }
    };
    template<unsigned nvi_to_subs,unsigned skin,unsigned num_sub_element,unsigned inner=0>
    struct ElementChoice {
        typedef void NE;
        typedef DefaultBehavior BE;
        typedef VoidDMSet TData;
    };
    template<unsigned skin,unsigned inner> struct ElementChoice<0,skin,0,inner> {
        typedef Hexa NE;
        typedef DefaultBehavior BE;
        typedef TCDM0 TData;
    };
    template<unsigned skin,unsigned inner> struct ElementChoice<1,skin,0,inner> {
        typedef Quad NE;
        typedef DefaultBehavior BE;
        typedef TCDM0 TData;
    };
    template<unsigned skin,unsigned inner> struct ElementChoice<2,skin,0,inner> {
        typedef Bar NE;
        typedef DefaultBehavior BE;
        typedef TCDM0 TData;
    };
    template<unsigned inner> struct ElementChoice<3,0,0,inner> {
        typedef NodalElement NE;
        typedef DefaultBehavior BE;
        typedef TCDM0 TData;
    };
};

};

#endif 
