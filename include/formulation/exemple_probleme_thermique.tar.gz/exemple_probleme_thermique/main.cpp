#include "build/problem_zebulon_thermique/problem.h"
#include "mesh/read_msh_2.h"
#include "mesh/make_rect.h"

using namespace LMT;
using namespace std;

void testformulation() {
    typedef Problem_zebulon_thermique<double,2> PB;
    typedef PB::TM TM;
    typedef TM::Pvec Pvec;

    TM m; // declaration d'un maillage
    //read_msh_2( m, "m.rect.msh" ); // chargement d'un maillage au format de gmsh dans m
    make_rect(m,Triangle(),Pvec(0.,0.),Pvec(1.,1.),Pvec(10,10)); // création d'un maillage rectangulaire avec 10 noeuds par côté. Le coin en bas à gauche a pour coordonnées cartésiennes (0,0) et le coin en haut à droite (1,1)

    // création d'un problème du type Problem_zebulon_thermique<double,2> avec le maillage m.
    PB pb( m );

    if (m.node_list.size()) {
            Pvec xmax = m.node_list[0].pos;
            Pvec xmin = m.node_list[0].pos;
            double pen = 40.;

            // détermination du noeud le plus en bas à gauche et du plus haut à droite.
            for(unsigned i=0;i<m.node_list.size();++i) { 
                    xmax = LMT::max( xmax, m.node_list[i].pos );
                    xmin = LMT::min( xmin, m.node_list[i].pos );
            }
            PRINT(xmin);
            PRINT(xmax);
            // Cette boucle parcours tous les noeuds et suivant leur position par rapport au point xmin et xman, le champ temperature reçoit une valeur correspondant à une contrainte.
            for(unsigned i=0;i<m.node_list.size();++i) {
                    // X min
                    // pos[0] <-> x
                    // pos[1] <-> y
                    if ( m.node_list[i].pos[0] < xmin[0] + 1e-6 ) {
                            //             pb.formulation_difftherm->add_constraint( "node["+to_string(i)+"].dep[0] - 0.3*time", pen );
                            //             pb.formulation_difftherm->add_constraint( "node["+to_string(i)+"].dep[1]", pen );
                            pb.formulation_difftherm->add_constraint( "node["+to_string(i)+"].temperature - 1", pen+30.*m.node_list[i].pos[1] );
                    }
                    // X max
                    if ( m.node_list[i].pos[0] > xmax[0] - 1e-6 ) {
                            pb.formulation_difftherm->add_constraint( "node["+to_string(i)+"].temperature", pen );
                            //             pb.formulation_difftherm->add_constraint( "node["+to_string(i)+"].dep[0] + 0.3*time", pen );
                            //             pb.formulation_difftherm->add_constraint( "node["+to_string(i)+"].dep[1]", pen );
                    }
            }
    }
    pb.formulation_difftherm->solve();

    display_mesh( m );
    //     DisplayParaview dp;
    //     dp.add_mesh( m );
    //     dp.exec();
}

int main(int argc,char **argv) {
    testformulation();
}