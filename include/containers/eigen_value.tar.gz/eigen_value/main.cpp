
#include <containers/vec.h>
#include <containers/eigen.h>

#include <cmath>
#include <cstdlib>

using namespace LMT;
using namespace std ;


int main(int argc, char* argv[] ) {

    typedef double T;
    Vec<T,3> vec(1,2,3);
    Vec <T,2> eigenvalues;
    Vec <Vec<T,2>,2>  eigenvectors;

    get_eigen_values_and_vectors (vec, eigenvalues, eigenvectors);
    PRINT(eigenvalues);
    PRINT( eigenvectors[0]);
    PRINT( eigenvectors[1]);
    
    return 0 ;
}
