#include "mesh/make_rect.h"
#include <correlation/DicCPU.h>

using namespace LMT;

int main( int argc, char **argv ) {
    typedef DicCPU<double,2>::TM_exemple TM;
    typedef TM::Pvec Pvec;
       
    ImgInterp<double,2> f( "Croix/plateblanche001_0078.png" );
    ImgInterp<double,2> g( "Croix/plateblanche001_0079.png" );
   
    TM m;
    make_rect( m, Quad(), Pvec(100,10), Pvec(1190,990), 20 );
    
    DicCPU<double,2> dic;
    dic.min_norm_inf_dU = 1e-4;
//     dic.div_pixel = 4;
    dic.display_norm_inf_dU = true;

    dic.exec( f, g, m, dep_DM(), lum_DM() );
   
    for(int i=0;i<f.data.size();++i)
        f.data[ i ] += 10.0 * rand() / double( RAND_MAX );
    
    dic.exec( f, g, m, dep_DM(), lum_DM() );

    Vec<Pvec> gege = generate( m.node_list, ExtractDM<dep_DM>() );
    PRINT(gege);
   
//     std::ofstream out_file( "mon_resultat.m" );
//     out_file << "dep_0=[" << generate( m.node_list, ExtractDM<dep_0_DM>() ) << "];" << std::endl;
//     out_file << "dep_1=[" << generate( m.node_list, ExtractDM<dep_1_DM>() ) << "];" << std::endl;
//     PRINT(
//         standard_deviation(
//             generate( m.node_list, ExtractDM<dep_DM>() ) -
//             generate( m.node_list, ExtractDM<dep_DM>() )
//         )
//     );
//     dic.display_residual_img( f, g, m, dep_0_DM() );

    display_mesh( m );
}


// from http://www.taygeta.com/random/gaussian.html
// Algorithm by Dr. Everett (Skip) Carter, Jr.
/*
         float x1, x2, w, y1, y2;
 
         do {
                 x1 = 2.0 * ranf() - 1.0;
                 x2 = 2.0 * ranf() - 1.0;
                 w = x1 * x1 + x2 * x2;
         } while ( w >= 1.0 );

         w = sqrt( (-2.0 * ln( w ) ) / w );
         y1 = x1 * w;
         y2 = x2 * w;*/
